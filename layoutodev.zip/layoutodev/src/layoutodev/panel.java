package layoutodev;

/**
 *
 * @author hakanyolat
 */
import java.awt.*;
import javax.swing.*;
public class panel extends JPanel{
    public panel(LayoutManager yerlesim){
        setLayout(yerlesim);
    }
}
