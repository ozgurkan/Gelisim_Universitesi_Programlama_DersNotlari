package layoutodev;

/**
 *
 * @author hakanyolat
 */
import javax.swing.*;
public class pencere extends JFrame {
    public pencere(String baslik, int width, int height){
        setTitle(baslik);
        setSize(width,height);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }
}
