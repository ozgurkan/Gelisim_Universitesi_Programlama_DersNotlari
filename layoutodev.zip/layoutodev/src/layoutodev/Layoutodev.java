package layoutodev;

/**
 *
 * @author hakanyolat
 */
import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
public class Layoutodev {
    public static void main(String[] args) {
        /*
         * Ekran(JFrame) ve ana panel(BorderLayout) oluşturuluyor
        */
        pencere ekran = new pencere("Ödev", 600, 600);
        panel anakutu = new panel(new BorderLayout(3,3));
        
        /*
         * Üst kısımda bir yazı göstermek için JLabel oluşturuluyor
         * Daha sonra üst kısım için bir FlowLayout'a sahip panel oluşturuluyor
        */
        JLabel header = new JLabel("Yerleşim Yöneticileri Ödevi");
        header.setFont(new Font("Calibri", Font.BOLD, 35));
        panel ustkutu = new panel(new FlowLayout(FlowLayout.CENTER));
        ustkutu.setBorder(new EmptyBorder(50,50,50,50));
        ustkutu.setBackground(Color.WHITE);
        ustkutu.add(header);
        
        /*
         * Sol taraf için GridLayout'a sahip bir panel oluşturuyoruz
         * Daha sonra içine butonları ekliyoruz
        */
        panel solkutu = new panel(new GridLayout(5, 1, 10, 10));
        solkutu.setBackground(Color.WHITE);
        solkutu.setBorder(new EmptyBorder(30,50,30,50));
        solkutu.add(new JButton("Anasayfa"));
        solkutu.add(new JButton("İletişim"));
        solkutu.add(new JButton("Hakkımızda"));
        solkutu.add(new JButton("Ürünler"));
        solkutu.add(new JButton("Stoklar"));
        
        /*
         *
        */
        panel merkezkutu = new panel(new GridLayout(8,1,5,5));
        merkezkutu.setBackground(Color.WHITE);
        merkezkutu.setBorder(new EmptyBorder(30,30,30,30));
        Font merkezFont = new Font("Calibri", Font.BOLD ,16);
        JLabel adsoyad = new JLabel("Ad-Soyad :");
        JLabel mail = new JLabel("Mail :");
        JLabel mesaj = new JLabel("Mesaj :");
        adsoyad.setFont(merkezFont);
        mail.setFont(merkezFont);
        mesaj.setFont(merkezFont);
        merkezkutu.add(adsoyad);
        merkezkutu.add(new JTextField());
        merkezkutu.add(mail);
        merkezkutu.add(new JTextField());
        merkezkutu.add(mesaj);
        merkezkutu.add(new JTextField());
        merkezkutu.add(new JLabel());
        merkezkutu.add(new JButton("Gönder"));
        
        /*
         *
        */
        anakutu.add(ustkutu,BorderLayout.NORTH);
        anakutu.add(solkutu,BorderLayout.WEST);
        anakutu.add(merkezkutu,BorderLayout.CENTER);
        ekran.add(anakutu);
    }
}
