package sinav;

/**
 *
 * @author hakanyolat
 */
public class Sinav {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        pencereOlustur ekran = new pencereOlustur("JAVA GRAFIK CIZDIRME",800,600);
        
    }
    
}
