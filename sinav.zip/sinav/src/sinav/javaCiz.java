/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package sinav;
import javax.swing.*;
import java.awt.Graphics;
/**
 *
 * @author hakanyolat
 */
public class javaCiz extends JPanel{
    @Override
    protected void paintComponent(Graphics g){
        super.paintComponent(g);
        // YAZI YAZMA
        g.drawString("Hakan YOLAT", 20, 30);
        
        // ÇİZGİ ÇİZME ( ÜÇGEN ÇİZİYORUM )
        g.drawLine(50, 200, 200, 50);
        g.drawLine(200, 50, 350, 200);
        g.drawLine(350, 200, 50, 200);
        
        // KARE VE İÇİ DOLU KARE ÇİZME ( PENCERE ÇİZİYORUM )
        g.drawRect(400, 50, 300, 160); // KARE
        g.fillRect(410, 60, 135, 140); // İÇİ DOLU KARE
        g.fillRect(555, 60, 135, 140); // İÇİ DOLU KARE
        
        // OVAL KENARLI VE İÇİ DOLU OVAL KENARLI KARE ÇİZME ( + İŞARETİ ÇİZİYORUM )
        g.drawRoundRect(100, 350, 200, 30, 25, 25); // OVAL KENARLI KARE
        g.fillRoundRect(185, 265, 30, 200, 25, 25); // OVAL KENARLI İÇİ DOLU KARE
        
        // OVAL, İÇİ DOLU OVAL, YAY VE İÇİ DOLU YAY ÇİZME ÇİZME
        g.drawOval(450, 300, 200, 200); // OVAL
        g.fillOval(480, 350, 50, 50); // İÇİ DOLU OVAL
        g.fillOval(570, 350, 50, 50); // İÇİ DOLU OVAL
        g.drawLine(480, 430, 620, 430); // ÇİZGİ ( GÜLÜŞÜN ÜST KISMI )
        g.drawArc(480, 380, 140, 100, 0, -180); // YAY
    }

}
