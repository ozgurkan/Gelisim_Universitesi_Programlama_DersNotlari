package sinav;

import javax.swing.*;

/**
 *
 * @author hakanyolat
 */
public class pencereOlustur extends JFrame{
    public pencereOlustur(String baslik, int genislik, int yukseklik){
        setTitle(baslik);
        setSize(genislik,yukseklik);
        setVisible(true);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        
        add(new javaCiz());
    }
}
