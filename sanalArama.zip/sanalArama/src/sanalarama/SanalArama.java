package sanalarama;

/**
 *
 * @author hakanyolat
 */
public class SanalArama {
    public static void main(String[] args) {
        
        tarife Turkcell = new tarife("Türkcell",1.2);
        tarife Avea = new tarife("Avea",1.4);
        tarife Vodafone = new tarife("Vodafone",1.3);
        
        kisi hakan = new kisi("Hakan YOLAT",Turkcell);
        kisi mert = new kisi("Mert KOCATEPE",Avea);
        kisi hamza = new kisi("Hamza ACAR",Vodafone);
        
        // Kontör Yüklemeden Aradığımızda bakiye mesajı verecektir.
        hakan.ara(mert, 2);
        // Kontör Yükleyip tekrar deneyelim...
        hakan.tlYukle(20);
        hakan.ara(mert,5);
        hakan.kalanTl();
        hakan.ara(hamza, 10);
        hakan.kalanTl();
        hamza.tlYukle(40);
        hamza.ara(hakan, 19);
        hamza.kalanTl();
        hamza.ara(mert, 5);
        hamza.kalanTl();
        mert.tlYukle(100);
        mert.ara(hakan, 36);
        mert.kalanTl();
        
        // Operatörlerin toplam kazancı
        Turkcell.toplamKazanc();
        Vodafone.toplamKazanc();
        Avea.toplamKazanc();
        
        // kurbanlar dizisinde tanımlı kişilerin hackerlar tarafından konuşma geçmişlerinin hacklenmesi :)
        kisi[] kurbanlar = {hakan,mert,hamza};
        hacker Ayyildiz = new hacker("Ayyıldız Tim");
        Ayyildiz.kurbanlar(kurbanlar);
        System.out.println("\n################## HACKED BY AYYILDIZ TIM ##################");
        Ayyildiz.hackle();
    }
    
}
