package sanalarama;

/**
 *
 * @author hakanyolat
 */
import java.util.*;
public class kisi {
    public ArrayList arayanKisiler = new ArrayList();
    public ArrayList arananKisiler = new ArrayList();
    public double kontor;
    public double dktl;
    public String adsoyad;
    public tarife operator;
    public kisi(String adsoyad, tarife dktl){
        this.adsoyad = adsoyad;
        this.kontor = 0;
        this.dktl = dktl.dktl;
        this.operator = dktl;
    }
    public void ara(kisi konusulan, double dakika){
        double tutar = dakika*this.dktl;
        if(kontor >= tutar){
            this.kontor -= dakika*this.dktl;
            this.arananKisiler.add(konusulan.adsoyad);
            konusulan.arayanKisiler.add(this.adsoyad);
            System.out.println(this.adsoyad+" adlı kişi "+konusulan.adsoyad+" adlı kişiyi aradı ve "+dakika+" dk. konuştu ( Tutar : "+tutar+" TL ).");
        }else{
            System.out.println(this.adsoyad+" adlı kişinin yeterli bakiyesi bulunmadığından "+konusulan.adsoyad+" adlı kişiyi arayamaz.");
        }
    }
    public void tlYukle(double tl){
        this.kontor += tl;
        this.operator.toplamKazanc += tl;
        System.out.println(this.adsoyad + " adlı kişiye "+tl+" TL yüklendi.");
    }
    public void kalanTl(){
        System.out.println(this.adsoyad + " adlı kişinin "+this.kontor+" TL bakiyesi bulunmaktadır.");
    }
}
