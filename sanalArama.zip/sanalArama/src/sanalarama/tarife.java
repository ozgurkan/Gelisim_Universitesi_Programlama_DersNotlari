
package sanalarama;

/**
 *
 * @author hakanyolat
 */
public class tarife {
    public String opAdi;
    public double dktl;
    public double toplamKazanc=0;
    public tarife(String operator, double dktl){
        this.opAdi = operator;
        this.dktl = dktl;
    }
    public void toplamKazanc(){
        System.out.println(this.opAdi+" Operatörünün toplam kazancı : "+toplamKazanc+" TL'dir.");
    }
}
